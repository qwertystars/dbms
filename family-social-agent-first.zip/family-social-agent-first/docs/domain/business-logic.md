# Business Logic

## Family ownership and membership

### RULE-FAMILY-01

Creating a family makes the creating account its `CREATOR`.

### RULE-FAMILY-02

A family has exactly one active Creator.

Creator ownership may be transferred, but the old creator must become another role or leave only after the transfer succeeds.

### RULE-FAMILY-03

An account may belong to multiple families.

### RULE-FAMILY-04

Within one family, an account has exactly one active membership.

## Permission matrix

| Action | Creator | Editor | Viewer |
|---|---:|---:|---:|
| View family | Yes | Yes | Yes |
| View tree | Yes | Yes | Yes |
| Export visible family data | Yes | Yes | Yes |
| Create person | Yes | Yes | No |
| Edit person | Yes | Yes | No |
| Delete person | Yes | No | No |
| Add parent/child relationship | Yes | Yes | No |
| Correct/remove parent/child relationship | Yes | Yes | No |
| Invite member | Yes | No | No |
| Change member role | Yes | No | No |
| Remove member | Yes | No | No |
| Transfer ownership | Yes | No | No |
| Delete family | Yes | No | No |
| Create family post | Yes | Yes | Yes |
| Comment/react | Yes | Yes | Yes |

The sketch gives Editor "add + edit". Removing an incorrect relationship is treated as tree editing, but deleting a person record remains Creator-only.

## Person profiles

### RULE-PERSON-01

A Person belongs to exactly one Family.

### RULE-PERSON-02

`name` and `gender` are required in v1.

### RULE-PERSON-03

If both dates exist:

`date_of_death >= date_of_birth`

### RULE-PERSON-04

A deceased person is represented with a Person record and optional `date_of_death`; no Account is required.

### RULE-PERSON-05

Linking a Person to an Account does not transfer ownership of that Person record. Family permissions still control editing.

### RULE-PERSON-06

Email and phone fields on Person are profile data. They are not authentication identifiers.

## Family graph

### RULE-TREE-01

A parent and child must belong to the same family.

### RULE-TREE-02

A person cannot be their own parent or descendant.

### RULE-TREE-03

Adding an edge `parent -> child` must be rejected if `child` already reaches `parent`.

### RULE-TREE-04

The same parent/child edge may exist only once.

### RULE-TREE-05

Deleting a Person requires handling all incident relationship edges in the same transaction.

### RULE-TREE-06

Generation numbers are computed for a requested visualization. They are not identity and must not be used as permanent keys.

## Invitations

### RULE-INVITE-01

Only the Creator may issue family invitations in v1.

### RULE-INVITE-02

Invitation roles may be only `EDITOR` or `VIEWER`.

### RULE-INVITE-03

An invitation must have:

- a cryptographically random token
- only a token hash stored server-side
- expiry
- single-use semantics

### RULE-INVITE-04

Accepting an invitation for an account that is already a family member is idempotent and must not create a duplicate membership.

## Social content

### RULE-POST-01

A post belongs to exactly one family and one authoring account.

### RULE-POST-02

The author must have active membership in the post's family at creation time.

### RULE-POST-03

All active family roles may post, comment, and react.

### RULE-POST-04

Users may edit/delete their own posts and comments.

The Creator may moderate content inside the family.

### RULE-POST-05

Removing a membership prevents future access to family posts but does not automatically erase that account's historical contributions.

## Friendship

### RULE-FRIEND-01

Friend requests are account-to-account, not Person-to-Person.

### RULE-FRIEND-02

An account cannot friend itself.

### RULE-FRIEND-03

There can be at most one pending friend request between the same two accounts in either direction.

### RULE-FRIEND-04

Accepted friendship is symmetric.

### RULE-FRIEND-05

Friendship never grants family membership or access to family-private data.

## Media

### RULE-MEDIA-01

A media asset has exactly one owning account and an application-level purpose.

### RULE-MEDIA-02

A client must not directly choose permanent object-storage keys.

### RULE-MEDIA-03

The server validates metadata before accepting an upload completion:

- allowed MIME type
- maximum size
- expected ownership/purpose

## Deletion

### RULE-DELETE-01

Person deletion is Creator-only because it can change family history.

### RULE-DELETE-02

Family deletion is Creator-only and requires an explicit confirmation step.

### RULE-DELETE-03

Family deletion must remove or tombstone all family-owned application records and schedule deletion of family-owned media.

## Audit

### RULE-AUDIT-01

Audit events record actor, action, target, family, timestamp, and request/correlation ID.

### RULE-AUDIT-02

Audit logs should record changed field names or summaries rather than copying sensitive profile values unless specifically required.
